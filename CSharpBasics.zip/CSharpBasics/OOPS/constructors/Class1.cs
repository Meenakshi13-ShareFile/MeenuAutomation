﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBasics.OOPS.constructors
{
    internal class Class1 //: Students
    {


        static void Main(string[] args)
        {
           // Students s = new Students();
        }
    }
}
