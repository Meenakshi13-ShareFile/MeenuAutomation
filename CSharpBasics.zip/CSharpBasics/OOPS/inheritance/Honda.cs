﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBasics.OOPS.inheritance
{
    internal class Honda : Car
    {

        static void Main(String[] args)
        {

            Honda car = new Honda();
            car.Start();
        }
    }
}
