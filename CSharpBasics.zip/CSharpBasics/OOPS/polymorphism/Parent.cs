﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBasics.OOPS.polymorphism
{
    internal abstract class Parent
    {
        //Can we create a non abstract method in an Abstract class


        public Parent() { 
        
        }

        public abstract void Display();
       

        public void Show()
        {

        }


        //sv - Main
        //cw - Console.WriteLine
        static void Main(string[] args)
        {

          



        }

    }
}
