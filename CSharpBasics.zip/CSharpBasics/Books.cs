﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBasics
{
    internal class Books
    {

        public static int numberOfBooks = 100;



        public static void displayNumbersOfBooks()
        {

            Console.WriteLine(numberOfBooks);
        }

    }
}
