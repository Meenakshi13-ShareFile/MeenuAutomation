﻿/*using OpenQA.Selenium.Chrome;
using System.Diagnostics;

Console.WriteLine("Hello World !!!");

//ChromeDriver driver = new ChromeDriver();
//driver.Url = "http://way2automation.com";
//Console.WriteLine(driver.Title);
//Debug.WriteLine(driver.Title);
//driver.Close(); //close the browser
//driver.Quit(); //close the browser


*//*
*Data Types and Variables
 * There are 4 types of Data Types in C#
 * 
 * 1. Reference Types: class, interface, string, array, delegates etc
 * 2. Value Types or Built-in types: int, long, float, double, char, boolean etc
 * 3. Pointer Types: *,&
 *4.Nullable Types: Nullables Types in C# are types that allow variables to be assigned a value or null
 *


*//*
//Value Types:


int age = 30; //4 byte memory ---> 1 byte is 8 bit --. 32 bit memory allocated -2,147,483,648 to 2,147,483,647

Console.WriteLine(age);
Debug.WriteLine(age);


long l = 2394723842348234L;

float f = 0.934f; ///32 bits (4 bytes)

double d = 1999.2323; // (8 bytes)


char letter = 'A';

string name = "Rahul";

Boolean isTrue = false;

uint num = 10; //(unassigned int) only stores positive values
ulong uLong = 1000000;


short s = 1003;
ushort us = 343;


byte b = 255; //range 0 - 255 1 byte = 8 bits;
sbyte sb = 127; // range -128 to 127 = 8 bits


var something = 100;
Debug.WriteLine(something);

//something = "Rahul";


dynamic somethingnew = 100;
somethingnew = "Rahul";

Debug.WriteLine("Hello {0}, you are {1} years old", name, age);

Debug.WriteLine("Hello " + name + ", you are " + age + " years old");


Debug.WriteLine($"Hello {name}, you are {age} years old");

Console.WriteLine("Enter your age: ");
int userAge = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Your new age is : " + userAge);







// Car which has properties like: color, brand and speed etc and methods brake(), accelerate()






*/